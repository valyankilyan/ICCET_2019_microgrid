from main import Server 

server = Server()

while(True):
	server.send(raw_input())