from Error import Error
from Data import Data
from Variables import Variables
from Change import Change
import os

error = Error()
data = Data()
var = Variables()
change = Change()


class Hydrate:
	
	def __init__(self):
		print("init Hydrate")

	def choise(self):
		print("choise Hydrate")