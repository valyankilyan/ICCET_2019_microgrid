class Prosumer:
	
	def __init__(self):
		print("init Prosumer")

	def choise(self):
		print("choise Prosumer")